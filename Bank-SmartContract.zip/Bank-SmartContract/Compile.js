const solc = require('solc');
const fs = require('fs');

if (!fs.existsSync('build')) {
    fs.mkdirSync('build');
}

const source = fs.readFileSync('Bank.sol', 'utf8');

const input = {
    language: 'Solidity',
    sources: {
        'Bank.sol': {
            content: source
        }
    },
    settings: {
        outputSelection: {
            '*': {
                '*': ['abi', 'evm.bytecode']
            }
        }
    }
};

const output = JSON.parse(solc.compile(JSON.stringify(input)));

if (!output.contracts || !output.contracts['Bank.sol']) {
    console.error("❌ Compilation failed:", output.errors);
    process.exit(1);
}

const contract = output.contracts['Bank.sol']['Bank'];

fs.writeFileSync('build/Bank.abi', JSON.stringify(contract.abi));
fs.writeFileSync('build/Bank.bin', contract.evm.bytecode.object);

console.log("✔ Compile successful!");
