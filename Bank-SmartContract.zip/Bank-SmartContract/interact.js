const {Web3} = require('web3');
const fs = require('fs');

if (!fs.existsSync('contract-address.txt')) {
    console.error("❌ Contract not deployed. Run deploy.js.");
    process.exit(1);
}

const web3 = new Web3('http://127.0.0.1:8545');

const abi = JSON.parse(fs.readFileSync('build/Bank.abi', 'utf8'));
const address = fs.readFileSync('contract-address.txt', 'utf8').trim();

const bank = new web3.eth.Contract(abi, address);

const run = async () => {
    const accounts = await web3.eth.getAccounts();

    console.log("✔ Depositing amounts...");
    await bank.methods.deposit().send({ from: accounts[0], value: web3.utils.toWei('1', 'ether') });
    await bank.methods.deposit().send({ from: accounts[1], value: web3.utils.toWei('2', 'ether') });

    console.log("✔ Withdrawing...");
    await bank.methods.withdraw(web3.utils.toWei('0.5', 'ether')).send({ from: accounts[0] });

    const bal1 = await bank.methods.getBalance().call({ from: accounts[0] });
    const bal2 = await bank.methods.getBalance().call({ from: accounts[1] });

    console.log("Balance of Account 0:", web3.utils.fromWei(bal1, 'ether'), "ETH");
    console.log("Balance of Account 1:", web3.utils.fromWei(bal2, 'ether'), "ETH");
};

run();
