const path = require("path");
const fs = require("fs");
const solc = require("solc");

// Read the Solidity file
const source = fs.readFileSync("Voting.sol", "utf8");

// Solidity compiler input format
const input = {
    language: "Solidity",
    sources: {
        "Voting.sol": { content: source }
    },
    settings: {
        outputSelection: {
            "*": {
                "*": ["abi", "evm.bytecode"]
            }
        }
    }
};

// Compile
const output = JSON.parse(solc.compile(JSON.stringify(input)));

// Extract ABI & bytecode
const contractName = "Voting";
const abi = output.contracts["Voting.sol"][contractName].abi;
const bytecode = output.contracts["Voting.sol"][contractName].evm.bytecode.object;

// Ensure compile folder exists
if (!fs.existsSync("compile")) {
    fs.mkdirSync("compile");
}

// Save ABI as Voting.abi
fs.writeFileSync(
    "compile/Voting.abi",
    JSON.stringify(abi, null, 2)
);

// Save bytecode as Voting.bin
fs.writeFileSync(
    "compile/Voting.bin",
    bytecode
);

// (Optional) also save these:
fs.writeFileSync("abi.json", JSON.stringify(abi, null, 2));
fs.writeFileSync("bytecode.json", bytecode);

console.log("Compilation successful!");
console.log("Files created:");
console.log("- compile/Voting.abi");
console.log("- compile/Voting.bin");
console.log("- abi.json");
console.log("- bytecode.json");
