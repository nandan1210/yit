const {Web3} = require("web3");
const fs = require("fs");

const web3 = new Web3("http://127.0.0.1:8545");

const abi = JSON.parse(fs.readFileSync("./compile/Voting.abi", "utf-8"));
const bytecode = fs.readFileSync("./compile/Voting.bin", "utf-8");

async function deploy() {
    const accounts = await web3.eth.getAccounts();
    const owner = accounts[0];

    console.log("Deploying from:", owner);

    const contract = new web3.eth.Contract(abi);

    const instance = await contract.deploy({ data: bytecode })
        .send({ from: owner, gas: 3000000 });

    console.log("Contract deployed at:", instance.options.address);

    fs.writeFileSync("contract-address.txt", instance.options.address);
}

deploy();
