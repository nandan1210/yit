const {Web3} = require("web3");
const fs = require("fs");

const web3 = new Web3("http://127.0.0.1:8545");

// Load ABI + Bytecode
const abi = JSON.parse(fs.readFileSync("./compile/Voting.abi", "utf-8"));
const contractAddress = fs.readFileSync("./contract-address.txt", "utf-8").trim();

// Load contract instance
const contract = new web3.eth.Contract(abi, contractAddress);

async function run() {
    const accounts = await web3.eth.getAccounts();
    const owner = accounts[0]; // FORCE OWNER = accounts[0]

    console.log("Using owner account:", owner);

    // CHECK OWNER IN CONTRACT
    let onchainOwner = await contract.methods.owner().call();
    console.log("Owner stored in contract:", onchainOwner);

    if (owner.toLowerCase() !== onchainOwner.toLowerCase()) {
        console.log("\n❌ ERROR: Owner mismatch! Candidates cannot be added.\n");
        return;
    }

    // ADD CANDIDATES
    async function addCandidate(name) {
        try {
            let tx = await contract.methods.addCandidate(name)
                .send({ from: owner, gas: 200000 });

            console.log(`Candidate '${name}' ADDED`);
        } catch (err) {
            console.log(`❌ Failed to add '${name}':`, err.toString());
        }
    }

    await addCandidate("Alice");
    await addCandidate("Bob");

    // CHECK TOTAL CANDIDATES
    const total = await contract.methods.getTotalCandidates().call();
    console.log("\nTotal candidates:", total);
}

run();
